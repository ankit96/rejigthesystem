import cPickle
stopwords=cPickle.load(open('stopwords.p', 'rb'))
parliament=cPickle.load(open('Parliamentaryaffairs.p', 'rb'))

redundant=[':',",",")",".","(",";","/","|","-"]
i=0
for a in parliament:
	while a[-1] in redundant:
		a.pop()
	while a[0] in redundant:
		a.pop(0)
	if a in stopwords:
		parliament.pop(i)
	i=i+1
	
	
	

cPickle.dump(parliament, open('Parliamentaryaffairs.p', 'wb')) 
		
print str(parliament)
