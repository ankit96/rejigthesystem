apostrope={"aren't":"are not","could've":"could have","can't":"cannot","couldn't":"could not","didn't":"did not","don't":"do not","'s":"is",
"hadn't":"had not","hasn't":"has not","haven't":"have not","he'd":"he had"}


